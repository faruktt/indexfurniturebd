<?php $__env->startSection('title', 'Edit Child Category'); ?>
<?php $__env->startSection('page_title', 'Edit Child Category: ' . $childcategory->name); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width: 650px; margin: 0 auto;">
    <div class="card-header">
        <h3 class="card-title">Edit Child Category</h3>
        <a href="<?php echo e(route('admin.childcategories.index')); ?>" class="btn btn-outline btn-sm">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>

    <div class="card-body">
        <form action="<?php echo e(route('admin.childcategories.update', $childcategory->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label class="form-label">Parent Category *</label>
                <select name="category_id" id="categorySelect" required class="form-control" onchange="loadSubcategories(this.value)">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e($childcategory->category_id == $cat->id ? 'selected' : ''); ?>>
                            <?php echo e($cat->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Subcategory *</label>
                <select name="sub_category_id" id="subCategorySelect" required class="form-control">
                    <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sub->id); ?>" <?php echo e($childcategory->sub_category_id == $sub->id ? 'selected' : ''); ?>>
                            <?php echo e($sub->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Child Category Name *</label>
                <input type="text" name="name" value="<?php echo e(old('name', $childcategory->name)); ?>" required class="form-control">
            </div>

            <div class="form-group">
                <label class="form-label">Child Category Image (Uploads to public/uploads/)</label>
                <?php if($childcategory->image): ?>
                    <div style="margin-bottom: 8px;">
                        <img src="<?php echo e($childcategory->image_url); ?>" alt="Preview" style="height: 60px; border-radius: 4px; border: 1px solid #ccc; padding: 2px;">
                        <span style="font-size: 11px; color: #64748b; margin-left: 8px;"><code><?php echo e($childcategory->image); ?></code></span>
                    </div>
                <?php endif; ?>
                <input type="file" name="image" class="form-control" accept="image/*">
                <div style="font-size: 11px; color: #64748b; margin-top: 4px;">Leave blank to keep existing image</div>
            </div>

            <div class="form-group">
                <label class="form-label">Display Order</label>
                <input type="number" name="order" value="<?php echo e(old('order', $childcategory->order)); ?>" class="form-control">
            </div>

            <div class="form-group">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="status" value="1" <?php echo e($childcategory->status ? 'checked' : ''); ?>>
                    <span>Active Status</span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Update Child Category
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function loadSubcategories(categoryId) {
        const select = document.getElementById('subCategorySelect');
        select.innerHTML = '<option value="">Loading...</option>';

        fetch(`<?php echo e(url('admin/api/subcategories')); ?>/${categoryId}`)
            .then(res => res.json())
            .then(data => {
                let html = '<option value="">Select Subcategory</option>';
                data.forEach(sub => {
                    html += `<option value="${sub.id}">${sub.name}</option>`;
                });
                select.innerHTML = html;
            });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/admin/childcategories/edit.blade.php ENDPATH**/ ?>