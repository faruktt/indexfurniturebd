<?php if($paginator->hasPages()): ?>
    <div class="admin-pagination-container">
        <div class="pagination-info">
            Showing <span class="font-semibold"><?php echo e($paginator->firstItem()); ?></span> to <span class="font-semibold"><?php echo e($paginator->lastItem()); ?></span> of <span class="font-semibold"><?php echo e($paginator->total()); ?></span> results
        </div>

        <nav role="navigation" aria-label="Pagination Navigation" class="pagination-nav">
            <ul class="admin-pagination-list">
                
                <?php if($paginator->onFirstPage()): ?>
                    <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                        <span class="page-link" aria-hidden="true">
                            <i class="fas fa-chevron-left" style="font-size: 11px;"></i>
                        </span>
                    </li>
                <?php else: ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                            <i class="fas fa-chevron-left" style="font-size: 11px;"></i>
                        </a>
                    </li>
                <?php endif; ?>

                
                <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(is_string($element)): ?>
                        <li class="page-item disabled" aria-disabled="true"><span class="page-link"><?php echo e($element); ?></span></li>
                    <?php endif; ?>

                    
                    <?php if(is_array($element)): ?>
                        <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($page == $paginator->currentPage()): ?>
                                <li class="page-item active" aria-current="page"><span class="page-link"><?php echo e($page); ?></span></li>
                            <?php else: ?>
                                <li class="page-item"><a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <?php if($paginator->hasMorePages()): ?>
                    <li class="page-item">
                        <a class="page-link" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                            <i class="fas fa-chevron-right" style="font-size: 11px;"></i>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                        <span class="page-link" aria-hidden="true">
                            <i class="fas fa-chevron-right" style="font-size: 11px;"></i>
                        </span>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
<?php elseif($paginator->total() > 0): ?>
    <div class="admin-pagination-container">
        <div class="pagination-info">
            Showing <span class="font-semibold">1</span> to <span class="font-semibold"><?php echo e($paginator->total()); ?></span> of <span class="font-semibold"><?php echo e($paginator->total()); ?></span> results
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/vendor/pagination/admin.blade.php ENDPATH**/ ?>