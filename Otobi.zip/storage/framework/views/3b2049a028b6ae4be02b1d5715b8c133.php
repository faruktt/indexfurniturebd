<?php $__env->startSection('title', 'Child Categories'); ?>
<?php $__env->startSection('page_title', 'Child Category Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">All Child Categories (<?php echo e($childCategories->total()); ?>)</h3>
        <a href="<?php echo e(route('admin.childcategories.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add Child Category
        </a>
    </div>

    <div class="table-responsive">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Child Category Name</th>
                    <th>Slug</th>
                    <th>Subcategory</th>
                    <th>Parent Category</th>
                    <th>Order</th>
                    <th>Status</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $childCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="font-weight: 700; color: #0f172a;"><?php echo e($child->name); ?></td>
                        <td style="color: #64748b;"><code><?php echo e($child->slug); ?></code></td>
                        <td>
                            <span class="badge badge-info"><?php echo e($child->subCategory->name ?? 'None'); ?></span>
                        </td>
                        <td>
                            <span class="badge badge-secondary"><?php echo e($child->category->name ?? 'None'); ?></span>
                        </td>
                        <td><?php echo e($child->order); ?></td>
                        <td>
                            <?php if($child->status): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Disabled</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right; white-space: nowrap;">
                            <a href="<?php echo e(route('admin.childcategories.edit', $child->id)); ?>" class="btn btn-outline btn-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.childcategories.destroy', $child->id)); ?>" method="POST" style="display: inline-block;" onsubmit="return confirm('Delete this child category?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-danger-sm">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 30px; color: #94a3b8;">
                            No child categories created yet.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($childCategories->links('vendor.pagination.admin')); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/admin/childcategories/index.blade.php ENDPATH**/ ?>