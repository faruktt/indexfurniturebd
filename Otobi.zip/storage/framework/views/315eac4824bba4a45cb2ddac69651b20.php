<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('page_title', 'Product Catalog'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header" style="flex-wrap: wrap; gap: 10px;">
        <div style="display: flex; align-items: center; gap: 15px;">
            <h3 class="card-title">All Products (<?php echo e($products->total()); ?>)</h3>
            <form action="<?php echo e(route('admin.products.index')); ?>" method="GET" style="display: flex; gap: 8px;">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search by title or code..." class="form-control" style="width: 200px; padding: 5px 10px; font-size: 12px;">
                <select name="category_id" class="form-control" style="width: 160px; padding: 5px 10px; font-size: 12px;" onchange="this.form.submit()">
                    <option value="">All Categories</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->id); ?>" <?php echo e(request('category_id') == $c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit" class="btn btn-dark btn-sm"><i class="fas fa-search"></i></button>
            </form>
        </div>

        <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add New Product
        </a>
    </div>

    <div class="table-responsive">
        <table class="admin-table">
            <thead>
                <tr>
                    <th style="width: 50px;">Image</th>
                    <th>Product Title</th>
                    <th>Code</th>
                    <th>Category</th>
                    <th>Subcategory</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Status</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->title); ?>" style="width: 44px; height: 44px; object-fit: contain; background: #fff; border: 1px solid #e2e8f0; border-radius: 4px;">
                        </td>
                        <td>
                            <div style="font-weight: 700; color: #0f172a;"><?php echo e($product->title); ?></div>
                            <div style="font-size: 11px; color: #64748b;">DB Image: <code><?php echo e($product->image ?? 'none'); ?></code></div>
                        </td>
                        <td>
                            <span class="badge badge-secondary"><?php echo e($product->product_code ?? 'N/A'); ?></span>
                        </td>
                        <td><?php echo e($product->category->name ?? 'None'); ?></td>
                        <td><?php echo e($product->subCategory->name ?? '-'); ?></td>
                        <td>
                            <strong style="color: var(--admin-primary);"><?php echo e($product->formatted_price); ?></strong>
                            <?php if($product->discount_price > 0): ?>
                                <div style="font-size: 11px; color: #94a3b8; text-decoration: line-through;"><?php echo e($product->formatted_regular_price); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($product->stock > 5): ?>
                                <span class="badge badge-success"><?php echo e($product->stock); ?> in stock</span>
                            <?php elseif($product->stock > 0): ?>
                                <span class="badge badge-warning">Low: <?php echo e($product->stock); ?></span>
                            <?php else: ?>
                                <span class="badge badge-danger">Out of stock</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($product->status): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Disabled</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right; white-space: nowrap;">
                            <a href="<?php echo e(route('products.show', $product->slug)); ?>" target="_blank" class="btn btn-outline btn-sm" title="View in Store">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                            <a href="<?php echo e(route('admin.products.edit', $product->id)); ?>" class="btn btn-outline btn-sm" title="Edit">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>" method="POST" style="display: inline-block;" onsubmit="return confirm('Delete this product permanently?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-danger-sm" title="Delete">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" style="text-align: center; padding: 30px; color: #94a3b8;">
                            No products found matching your search.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($products->links('vendor.pagination.admin')); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/admin/products/index.blade.php ENDPATH**/ ?>