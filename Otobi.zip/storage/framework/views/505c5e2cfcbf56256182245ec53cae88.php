<?php $__env->startSection('title', 'Categories'); ?>
<?php $__env->startSection('page_title', 'Category Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">All Categories (<?php echo e($categories->total()); ?>)</h3>
        <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add Category
        </a>
    </div>

    <div class="table-responsive">
        <table class="admin-table">
            <thead>
                <tr>
                    <th style="width: 60px;">Image</th>
                    <th>Category Name</th>
                    <th>Slug</th>
                    <th>Subcategories</th>
                    <th>Products</th>
                    <th>Popular Home</th>
                    <th>Popular Office</th>
                    <th>Featured</th>
                    <th>Status</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <img src="<?php echo e($cat->image_url); ?>" alt="<?php echo e($cat->name); ?>" style="width: 40px; height: 40px; object-fit: cover; border-radius: 4px; border: 1px solid #e2e8f0;">
                        </td>
                        <td style="font-weight: 700; color: #0f172a;"><?php echo e($cat->name); ?></td>
                        <td style="color: #64748b;"><code><?php echo e($cat->slug); ?></code></td>
                        <td><?php echo e($cat->sub_categories_count); ?></td>
                        <td><?php echo e($cat->products_count); ?></td>
                        <td>
                            <?php if($cat->is_popular_home): ?>
                                <span class="badge badge-success">Yes</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">No</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($cat->is_popular_office): ?>
                                <span class="badge badge-info">Yes</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">No</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($cat->is_featured): ?>
                                <span class="badge badge-warning">Featured</span>
                            <?php else: ?>
                                <span class="badge badge-secondary">Standard</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($cat->status): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Disabled</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right; white-space: nowrap;">
                            <a href="<?php echo e(route('admin.categories.edit', $cat->id)); ?>" class="btn btn-outline btn-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.categories.destroy', $cat->id)); ?>" method="POST" style="display: inline-block;" onsubmit="return confirm('Delete this category and its subcategories?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-danger-sm">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="10" style="text-align: center; padding: 30px; color: #94a3b8;">
                            No categories created yet.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($categories->links('vendor.pagination.admin')); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>