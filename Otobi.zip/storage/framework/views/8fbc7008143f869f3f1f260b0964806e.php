<?php $__env->startSection('title', 'Subcategories'); ?>
<?php $__env->startSection('page_title', 'Subcategory Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">All Subcategories (<?php echo e($subCategories->total()); ?>)</h3>
        <a href="<?php echo e(route('admin.subcategories.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add Subcategory
        </a>
    </div>

    <div class="table-responsive">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Subcategory Name</th>
                    <th>Slug</th>
                    <th>Parent Category</th>
                    <th>Child Categories</th>
                    <th>Order</th>
                    <th>Status</th>
                    <th style="text-align: right;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td style="font-weight: 700; color: #0f172a;"><?php echo e($sub->name); ?></td>
                        <td style="color: #64748b;"><code><?php echo e($sub->slug); ?></code></td>
                        <td>
                            <span class="badge badge-info"><?php echo e($sub->category->name ?? 'None'); ?></span>
                        </td>
                        <td><?php echo e($sub->child_categories_count); ?></td>
                        <td><?php echo e($sub->order); ?></td>
                        <td>
                            <?php if($sub->status): ?>
                                <span class="badge badge-success">Active</span>
                            <?php else: ?>
                                <span class="badge badge-danger">Disabled</span>
                            <?php endif; ?>
                        </td>
                        <td style="text-align: right; white-space: nowrap;">
                            <a href="<?php echo e(route('admin.subcategories.edit', $sub->id)); ?>" class="btn btn-outline btn-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('admin.subcategories.destroy', $sub->id)); ?>" method="POST" style="display: inline-block;" onsubmit="return confirm('Delete this subcategory?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn-danger-sm">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 30px; color: #94a3b8;">
                            No subcategories created yet.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo e($subCategories->links('vendor.pagination.admin')); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/admin/subcategories/index.blade.php ENDPATH**/ ?>