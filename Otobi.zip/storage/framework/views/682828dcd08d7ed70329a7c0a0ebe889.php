<?php $__env->startSection('title', 'Sliders & Banners'); ?>
<?php $__env->startSection('page_title', 'Hero Sliders & Banners Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Homepage Sliders (<?php echo e($sliders->count()); ?>)</h3>
        <a href="<?php echo e(route('admin.sliders.create')); ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Add New Slide / Upload Multiple
        </a>
    </div>

    <div class="card-body" style="padding: 0;">
        <div class="table-responsive">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 60px;">Order</th>
                        <th style="width: 160px;">Banner Preview</th>
                        <th>Title / Subtitle</th>
                        <th>Button &amp; Link</th>
                        <th>File Name (public/uploads/)</th>
                        <th style="width: 100px;">Status</th>
                        <th style="width: 140px; text-align: right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <span style="font-weight: 700; color: #475569;">#<?php echo e($slider->order); ?></span>
                            </td>
                            <td>
                                <div style="width: 150px; height: 65px; border-radius: 4px; overflow: hidden; background: #1e293b; border: 1px solid #cbd5e1;">
                                    <img src="<?php echo e($slider->image_url); ?>" alt="Slide" style="width: 100%; height: 100%; object-fit: cover;">
                                </div>
                            </td>
                            <td>
                                <div style="font-size: 11px; text-transform: uppercase; color: var(--admin-primary); font-weight: 700;">
                                    <?php echo e($slider->subtitle ?? 'No Subtitle'); ?>

                                </div>
                                <div style="font-weight: 700; font-size: 14px; color: #0f172a;">
                                    <?php echo e($slider->title ?? 'Untitled Slide'); ?>

                                </div>
                                <?php if($slider->description): ?>
                                    <div style="font-size: 11px; color: #64748b; margin-top: 2px; max-width: 320px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                        <?php echo e($slider->description); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($slider->btn_text): ?>
                                    <div style="font-size: 11px; font-weight: 600; color: #1e293b;">
                                        <?php echo e($slider->btn_text); ?>

                                    </div>
                                    <a href="<?php echo e($slider->btn_link ?? '#'); ?>" target="_blank" style="font-size: 11px; color: #64748b; text-decoration: underline;">
                                        <?php echo e($slider->btn_link ?? 'No Link'); ?>

                                    </a>
                                <?php else: ?>
                                    <span style="color: #94a3b8; font-size: 11px;">Image Only</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <code style="font-size: 11.5px; background: #f1f5f9; padding: 2px 6px; border-radius: 3px;">
                                    <?php echo e($slider->image); ?>

                                </code>
                            </td>
                            <td>
                                <form action="<?php echo e(route('admin.sliders.toggle', $slider->id)); ?>" method="POST" style="margin: 0;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" style="background: none; border: none; cursor: pointer; padding: 0;">
                                        <?php if($slider->status): ?>
                                            <span style="background: #dcfce7; color: #166534; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: 600;">
                                                <i class="fas fa-check-circle"></i> Active
                                            </span>
                                        <?php else: ?>
                                            <span style="background: #fee2e2; color: #991b1b; padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: 600;">
                                                <i class="fas fa-times-circle"></i> Inactive
                                            </span>
                                        <?php endif; ?>
                                    </button>
                                </form>
                            </td>
                            <td style="text-align: right;">
                                <div style="display: inline-flex; gap: 6px;">
                                    <a href="<?php echo e(route('admin.sliders.edit', $slider->id)); ?>" class="btn btn-outline btn-sm" title="Edit Slide">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.sliders.destroy', $slider->id)); ?>" method="POST" onsubmit="return confirm('Delete this slide banner?');" style="margin: 0;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn-danger-sm" title="Delete Slide">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 40px; color: #94a3b8;">
                                <i class="fas fa-images" style="font-size: 36px; margin-bottom: 10px; display: block;"></i>
                                No slides found. Click "Add New Slide" above to upload banner images.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/admin/sliders/index.blade.php ENDPATH**/ ?>