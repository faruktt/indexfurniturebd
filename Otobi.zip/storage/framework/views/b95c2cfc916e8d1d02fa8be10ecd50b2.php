<?php $__env->startSection('title', 'Edit Subcategory'); ?>
<?php $__env->startSection('page_title', 'Edit Subcategory: ' . $subcategory->name); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width: 650px; margin: 0 auto;">
    <div class="card-header">
        <h3 class="card-title">Edit Subcategory</h3>
        <a href="<?php echo e(route('admin.subcategories.index')); ?>" class="btn btn-outline btn-sm">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>

    <div class="card-body">
        <form action="<?php echo e(route('admin.subcategories.update', $subcategory->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label class="form-label">Parent Category *</label>
                <select name="category_id" required class="form-control">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e($subcategory->category_id == $cat->id ? 'selected' : ''); ?>>
                            <?php echo e($cat->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label class="form-label">Subcategory Name *</label>
                <input type="text" name="name" value="<?php echo e(old('name', $subcategory->name)); ?>" required class="form-control">
            </div>

            <div class="form-group">
                <label class="form-label">Subcategory Image (Uploads to public/uploads/)</label>
                <?php if($subcategory->image): ?>
                    <div style="margin-bottom: 8px;">
                        <img src="<?php echo e($subcategory->image_url); ?>" alt="Preview" style="height: 60px; border-radius: 4px; border: 1px solid #ccc; padding: 2px;">
                        <span style="font-size: 11px; color: #64748b; margin-left: 8px;"><code><?php echo e($subcategory->image); ?></code></span>
                    </div>
                <?php endif; ?>
                <input type="file" name="image" class="form-control" accept="image/*">
                <div style="font-size: 11px; color: #64748b; margin-top: 4px;">Leave blank to keep existing image</div>
            </div>

            <div class="form-group">
                <label class="form-label">Display Order</label>
                <input type="number" name="order" value="<?php echo e(old('order', $subcategory->order)); ?>" class="form-control">
            </div>

            <div class="form-group">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="status" value="1" <?php echo e($subcategory->status ? 'checked' : ''); ?>>
                    <span>Active Status</span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Update Subcategory
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/admin/subcategories/edit.blade.php ENDPATH**/ ?>