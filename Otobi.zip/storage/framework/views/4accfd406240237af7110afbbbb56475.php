<?php $__env->startSection('title', 'Edit Product'); ?>
<?php $__env->startSection('page_title', 'Edit: ' . $product->title); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width: 950px; margin: 0 auto;">
    <div class="card-header">
        <h3 class="card-title">Edit Product Details</h3>
        <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-outline btn-sm">
            <i class="fas fa-arrow-left"></i> Back to Products
        </a>
    </div>

    <div class="card-body">
        <form action="<?php echo e(route('admin.products.update', $product->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Row 1: Title & Code -->
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Product Title *</label>
                    <input type="text" name="title" value="<?php echo e(old('title', $product->title)); ?>" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Product Code / SKU</label>
                    <input type="text" name="product_code" value="<?php echo e(old('product_code', $product->product_code)); ?>" class="form-control">
                </div>
            </div>

            <!-- Row 2: Categories -->
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Category *</label>
                    <select name="category_id" id="prodCatSelect" required class="form-control" onchange="loadSubcategories(this.value)">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>" <?php echo e($product->category_id == $cat->id ? 'selected' : ''); ?>>
                                <?php echo e($cat->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Subcategory</label>
                    <select name="sub_category_id" id="prodSubCatSelect" class="form-control" onchange="loadChildCategories(this.value)">
                        <option value="">None</option>
                        <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sub->id); ?>" <?php echo e($product->sub_category_id == $sub->id ? 'selected' : ''); ?>>
                                <?php echo e($sub->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Child Category</label>
                    <select name="child_category_id" id="prodChildCatSelect" class="form-control">
                        <option value="">None</option>
                        <?php $__currentLoopData = $childCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($ch->id); ?>" <?php echo e($product->child_category_id == $ch->id ? 'selected' : ''); ?>>
                                <?php echo e($ch->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <!-- Row 3: Prices & Stock -->
            <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Regular Price (BDT) *</label>
                    <input type="number" step="0.01" name="price" value="<?php echo e(old('price', $product->price)); ?>" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Discount Price (BDT)</label>
                    <input type="number" step="0.01" name="discount_price" value="<?php echo e(old('discount_price', $product->discount_price)); ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Stock Quantity *</label>
                    <input type="number" name="stock" value="<?php echo e(old('stock', $product->stock)); ?>" required class="form-control">
                </div>
            </div>

            <!-- Row 4: Dimensions & Warranty -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Dimensions (WxDxH)</label>
                    <input type="text" name="dimension" value="<?php echo e(old('dimension', $product->dimension)); ?>" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Warranty Details</label>
                    <input type="text" name="warranty" value="<?php echo e(old('warranty', $product->warranty)); ?>" class="form-control">
                </div>
            </div>

            <!-- Row 5: Colors & Sizes -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px;">
                <div>
                    <label class="form-label">Available Colors</label>
                    <div style="max-height: 120px; overflow-y: auto; border: 1px solid #cbd5e1; border-radius: 4px; padding: 10px; background: #fff;">
                        <?php $productColorIds = $product->colors->pluck('id')->toArray(); ?>
                        <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px; font-size: 12px; cursor: pointer;">
                                <input type="checkbox" name="colors[]" value="<?php echo e($color->id); ?>" <?php echo e(in_array($color->id, $productColorIds) ? 'checked' : ''); ?>>
                                <span style="display: inline-block; width: 14px; height: 14px; background: <?php echo e($color->code ?? '#ccc'); ?>; border: 1px solid #aaa; border-radius: 2px;"></span>
                                <span><?php echo e($color->name); ?></span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div>
                    <label class="form-label">Available Sizes / Variations</label>
                    <div style="max-height: 120px; overflow-y: auto; border: 1px solid #cbd5e1; border-radius: 4px; padding: 10px; background: #fff;">
                        <?php $productSizeIds = $product->sizes->pluck('id')->toArray(); ?>
                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label style="display: flex; align-items: center; gap: 8px; margin-bottom: 6px; font-size: 12px; cursor: pointer;">
                                <input type="checkbox" name="sizes[]" value="<?php echo e($size->id); ?>" <?php echo e(in_array($size->id, $productSizeIds) ? 'checked' : ''); ?>>
                                <span><?php echo e($size->name); ?> (<?php echo e($size->code ?? 'N/A'); ?>)</span>
                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- Row 6: Image Uploads -->
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label class="form-label">Current Main Image</label>
                    <div style="margin-bottom: 8px;">
                        <img src="<?php echo e($product->image_url); ?>" alt="Main" style="width: 70px; height: 70px; object-fit: contain; border: 1px solid #ccc; border-radius: 4px;">
                        <div style="font-size: 11px; color: #64748b;">Filename in DB: <code><?php echo e($product->image ?? 'none'); ?></code></div>
                    </div>
                    <label class="form-label">Change Main Image (Uploads to public/uploads/)</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                </div>

                <div class="form-group">
                    <label class="form-label">Add More Gallery Images</label>
                    <input type="file" name="gallery[]" multiple class="form-control" accept="image/*">
                    <small style="color: #64748b; font-size: 11px;">Uploads to <code>public/uploads/</code>.</small>

                    <?php if($product->images->count() > 0): ?>
                        <div style="margin-top: 10px; display: flex; gap: 8px; flex-wrap: wrap;">
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div style="position: relative; width: 50px; height: 50px; border: 1px solid #ccc; border-radius: 4px; overflow: hidden;" id="gImg-<?php echo e($gImg->id); ?>">
                                    <img src="<?php echo e($gImg->image_url); ?>" style="width: 100%; height: 100%; object-fit: contain;">
                                    <button type="button" onclick="deleteGalleryImage(<?php echo e($gImg->id); ?>)" style="position: absolute; top: 0; right: 0; background: red; color: #fff; border: none; font-size: 9px; width: 16px; height: 16px; cursor: pointer;">&times;</button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Descriptions -->
            <div class="form-group">
                <label class="form-label">Short Tagline / Subtitle</label>
                <input type="text" name="short_description" value="<?php echo e(old('short_description', $product->short_description)); ?>" class="form-control">
            </div>

            <div class="form-group">
                <label class="form-label">Full Product Description &amp; Features</label>
                <textarea name="description" rows="5" class="form-control"><?php echo e(old('description', $product->description)); ?></textarea>
            </div>

            <!-- Checkboxes Row -->
            <div style="display: flex; gap: 25px; flex-wrap: wrap; margin: 20px 0; padding: 12px; background: #f8fafc; border-radius: 6px;">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="is_featured" value="1" <?php echo e(old('is_featured', $product->is_featured) ? 'checked' : ''); ?>>
                    <span>Featured Product</span>
                </label>

                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="is_popular" value="1" <?php echo e(old('is_popular', $product->is_popular) ? 'checked' : ''); ?>>
                    <span>Popular Product</span>
                </label>

                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="cash_on_delivery" value="1" <?php echo e(old('cash_on_delivery', $product->cash_on_delivery) ? 'checked' : ''); ?>>
                    <span>Cash on Delivery Available</span>
                </label>

                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="status" value="1" <?php echo e(old('status', $product->status) ? 'checked' : ''); ?>>
                    <span>Active Status</span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary" style="padding: 10px 28px;">
                <i class="fas fa-save"></i> Update Product
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function loadSubcategories(categoryId) {
        const subSelect = document.getElementById('prodSubCatSelect');
        const childSelect = document.getElementById('prodChildCatSelect');
        subSelect.innerHTML = '<option value="">Loading...</option>';
        childSelect.innerHTML = '<option value="">None</option>';

        fetch(`<?php echo e(url('admin/api/subcategories')); ?>/${categoryId}`)
            .then(res => res.json())
            .then(data => {
                let html = '<option value="">None</option>';
                data.forEach(sub => {
                    html += `<option value="${sub.id}">${sub.name}</option>`;
                });
                subSelect.innerHTML = html;
            });
    }

    function loadChildCategories(subCategoryId) {
        const childSelect = document.getElementById('prodChildCatSelect');
        childSelect.innerHTML = '<option value="">Loading...</option>';

        fetch(`<?php echo e(url('admin/api/childcategories')); ?>/${subCategoryId}`)
            .then(res => res.json())
            .then(data => {
                let html = '<option value="">None</option>';
                data.forEach(child => {
                    html += `<option value="${child.id}">${child.name}</option>`;
                });
                childSelect.innerHTML = html;
            });
    }

    function deleteGalleryImage(id) {
        if (!confirm('Remove this gallery image?')) return;

        fetch(`<?php echo e(url('admin/products/gallery-image')); ?>/${id}`, {
            method: 'DELETE',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                document.getElementById(`gImg-${id}`).remove();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>