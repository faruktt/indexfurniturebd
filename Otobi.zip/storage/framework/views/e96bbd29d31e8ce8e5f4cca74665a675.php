<?php $__env->startSection('title', 'Edit Category'); ?>
<?php $__env->startSection('page_title', 'Edit Category: ' . $category->name); ?>

<?php $__env->startSection('content'); ?>
<div class="card" style="max-width: 700px; margin: 0 auto;">
    <div class="card-header">
        <h3 class="card-title">Edit Category</h3>
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-outline btn-sm">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>

    <div class="card-body">
        <form action="<?php echo e(route('admin.categories.update', $category->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="form-group">
                <label class="form-label">Category Name *</label>
                <input type="text" name="name" value="<?php echo e(old('name', $category->name)); ?>" required class="form-control">
            </div>

            <div class="form-group">
                <label class="form-label">Display Order</label>
                <input type="number" name="order" value="<?php echo e(old('order', $category->order)); ?>" class="form-control">
            </div>

            <div class="form-group">
                <label class="form-label">Current Image</label>
                <div style="margin-bottom: 8px;">
                    <img src="<?php echo e($category->image_url); ?>" alt="Category" style="width: 80px; height: 80px; object-fit: cover; border-radius: 4px; border: 1px solid #e2e8f0;">
                    <div style="font-size: 11px; color: #64748b; margin-top: 4px;">Filename in DB: <code><?php echo e($category->image ?? 'None'); ?></code></div>
                </div>
                <label class="form-label">Change Image (Uploads to public/uploads/)</label>
                <input type="file" name="image" class="form-control" accept="image/*">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0;">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="is_popular_home" value="1" <?php echo e(old('is_popular_home', $category->is_popular_home) ? 'checked' : ''); ?>>
                    <span>Show in Popular Home Categories</span>
                </label>

                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="is_popular_office" value="1" <?php echo e(old('is_popular_office', $category->is_popular_office) ? 'checked' : ''); ?>>
                    <span>Show in Popular Office Categories</span>
                </label>

                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="is_featured" value="1" <?php echo e(old('is_featured', $category->is_featured) ? 'checked' : ''); ?>>
                    <span>Mark as Featured Category</span>
                </label>

                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12.5px;">
                    <input type="checkbox" name="status" value="1" <?php echo e(old('status', $category->status) ? 'checked' : ''); ?>>
                    <span>Active Status</span>
                </label>
            </div>

            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Update Category
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Md Zainal Abedin\Desktop\Otobi\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>