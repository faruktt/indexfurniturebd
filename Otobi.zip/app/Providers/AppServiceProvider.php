<?php

namespace App\Providers;

use App\Models\Page;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        View::composer(['frontend.layouts.app', 'frontend.*'], function ($view) {
            if (Schema::hasTable('pages')) {
                $footerCompanyPages = Page::where('status', true)
                    ->where('section', 'company')
                    ->orderBy('order', 'asc')
                    ->orderBy('id', 'asc')
                    ->get();

                $footerInfoPages = Page::where('status', true)
                    ->where('section', 'information')
                    ->orderBy('order', 'asc')
                    ->orderBy('id', 'asc')
                    ->get();

                $view->with(compact('footerCompanyPages', 'footerInfoPages'));
            }
        });
    }
}
